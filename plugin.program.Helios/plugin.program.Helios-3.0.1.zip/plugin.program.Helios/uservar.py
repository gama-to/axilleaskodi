import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://axilleaskodi.netlify.app/txt.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://axilleaskodi.netlify.app/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
